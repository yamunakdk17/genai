// import { RouterProvider } from "react-router-dom"
// import {router} from "./app.routes.jsx"
// import{AuthProvider} from "./features/auth/auth.context.jsx"
// import { InterviewProvider } from "./features/interview/interview.context";


// function App() {

//   return (
//     <AuthProvider>
//   < RouterProvider router = {router} /> 
//     </AuthProvider>

//   )
// }

// export default App 
import { RouterProvider } from "react-router-dom";
import { router } from "./app.routes.jsx";

import { AuthProvider } from "./features/auth/auth.context.jsx";
import { InterviewProvider } from "./features/interview/interview.context.jsx";

function App() {
  return (
    <AuthProvider>
      <InterviewProvider>
        <RouterProvider router={router} />
      </InterviewProvider>
    </AuthProvider>
  );
}

export default App;