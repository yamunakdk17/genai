import React,{useState} from 'react'
import { useNavigate, Link } from "react-router-dom"
import "../auth.form.scss"
import {useAuth } from '../hooks/useAuth'


const Login = () =>{
    const { loading, handleLogin } = useAuth()
     const navigate = useNavigate()


     const [email, setEmail] = useState("")
     const [password, setPassword] = useState("")

    // const handleSubmit = async (e) =>{
    //     e.preventDefault();
    //   await handleLogin({ email,password });
      

    // }
    const handleSubmit = async (e) => {
        e.preventDefault();

        console.log("Before login");

        const success = await handleLogin({
            email,
            password,
        });

        console.log("Login success =", success);

        if (success) {
            console.log("Navigating...");
            navigate("/");
        }
    };
    if(loading){
       return (<main><h1>Loading......</h1></main>) 
    }
    return (
        <main>
        <div className="form-container">
            <h1>Login </h1>
            <form onSubmit={handleSubmit}>
                

                <div className="input-group">

                    <label htmlFor="email">Email</label>
                    <input 
                    onChange={(e) => {setEmail (e.target.value)}}
                    type="email"id="email"name="email"placeholder='Enter email address'/>
                    

                </div>
                    <div className="input-group">

                        <label htmlFor="password">password</label>
                        <input
                            onChange={(e) => {
                                setPassword(e.target.value)}}
                        type="password" id="password" name="password" placeholder='Enter your password ' />


                    </div>
                    <button className='button primary-button'>Login</button>

              






            </form>
                <p>
                    Don't have an account ?
                    <Link to={"/Register"}>Register</Link>
                </p>  
            </div>            

        </main>
    )
}

export default Login ;








